#!/bin/bash

###############################################
# - 安装node_exporter，并注册成服务
###############################################
##
## Filename : install.sh
## Date     : 2023-07-27
## Author   : xiaoyunjie


APP_HOME=$(dirname $(readlink -f "$0"))

# Check if user is root
function check_user() {
    if [ $(id -u) != "0" ]; then
        echo " Not the root user! Try using sudo Command ! "
        exit 1
    fi
    echo "NOTE ! You are the root user!"
}

# Firewall add port
function add_port() {
    firewall-cmd --permanent --zone=public --add-port=9100/tcp >> logs/install.log 2>&1
    firewall-cmd --reload >> logs/install.log 2>&1
}

# Register the node_exporter service
function register_service() {
    /usr/bin/chmod +x ${APP_HOME}/bin/node_exporter  >> logs/install.log 2>&1
    /usr/bin/cp -rf ${APP_HOME}/bin/node_exporter /usr/local/bin/ >> logs/install.log 2>&1
    /usr/bin/cp -rf ${APP_HOME}/service/node_exporter.service  /usr/lib/systemd/system/  >> logs/install.log 2>&1
    systemctl daemon-reload
}

# enable and start node_exporter
function enable_start() {
    systemctl enable node_exporter.service
    systemctl start node_exporter.service
    systemctl status node_exporter.service
}


## main 
function main() {
    check_user
    add_port
    register_service
    enable_start
}

######
main
